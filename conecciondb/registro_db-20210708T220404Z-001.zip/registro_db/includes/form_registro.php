<?php
print_r("<pre>");
print_r($_POST);


?>